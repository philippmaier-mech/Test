Die Vorlage verwendet die modernere Literatur-Software biber (http://biblatex-biber.sourceforge.net) statt bibtex.

In TeXmaker müssen Sie unter Optionen -> Configure TeXmaker -> Commands -> Bib(la)tex auf "biber %" ohne Anführungszeichen setzen. Danach F1, F11, F1 drücken.

In texstudio (http://texstudio.sourceforge.net), das ich verwende, gibt's den biber Befehl unter Tools -> Commands -> Biber. Sie können in den Optionen auch einen shortcut darauf legen.


PDF/A and LaTeX:

- [Wikipedia: PDF/A](https://de.wikipedia.org/wiki/PDF/A)
- [pdfx](https://ctan.org/pkg/pdfx): The package helps LATEX users to create PDF/X, PFD/A and other standards-compliant PDF documents with pdfTEX, LuaTEX and XETEX.
- [converter](https://www.pdfen.com/convert-to-pdfa)
- [validator](https://www.pdfen.com/pdf-a-validator)
